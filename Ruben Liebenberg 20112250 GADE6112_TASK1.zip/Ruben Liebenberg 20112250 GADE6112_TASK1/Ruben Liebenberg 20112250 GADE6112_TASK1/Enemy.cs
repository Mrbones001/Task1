﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ruben_Liebenberg_20112250_GADE6112_TASK1
{
    abstract class Enemy : character
    {
        //protected variable 

        //random object for random number
        Random r = new Random();

        static int Randomnum(Random r)
        {
            return r.Next();
        }
        
       
        public Enemy(int X, int Y, int Denemy, int MaxHp) : base(X, Y)
        {
            
        }

        ///Q2.4 - 3 bullet
        





    }
}
