﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ruben_Liebenberg_20112250_GADE6112_TASK1
{
    abstract class character : Tile 
    {
        protected int HP;
        protected int MaxHP;
        protected int Damage;
        string Symbol;

        public int Hp { get => HP; set => HP = value; }
        public int Maxhp { get => MaxHP; set => MaxHP = value; }
        public int damage { get => Damage; set => Damage = value; }


        string[] Cvision = new string[4] { "north", "south", "east", "west" };
        
        public enum Movement {Nomovement, Up, Down, Left, Right  }

       
        public character(int X, int Y) : base(X, Y)
        {
  
        }
        public  void Attack(character target)
        {
            HP -= Damage;
        }

        public bool IsDead()
        {
            if (Hp <= 0)
            {
                return true;
            }
            else
                return false;      
        }

        public virtual bool CheckRange()
        {

        }

        private int DistanceTo()
        {
          
        }

        public void Move(Movement move)
        {
          switch (move)
            {
                case Movement.Nomovement:
                    x = x + 0;
                    y = y + 0;
                    break;
                case Movement.Up:
                    y = y + 1;
                    break;
                case Movement.Down:
                    y = y + 1;
                    break;
                case Movement.Right:
                    x = x + 1;
                    break;
                case Movement.Left:
                    x = x + 1;
                    break;    
            }

        }
        public void Move(MovementEnum move)
        {

        }
        
        public abstract MovementEnum ReturnMove()////???///
        {
          
        }

        public abstract override string ToString()////????///
        {
            character ToString = new ToString();
        }










    }
}
