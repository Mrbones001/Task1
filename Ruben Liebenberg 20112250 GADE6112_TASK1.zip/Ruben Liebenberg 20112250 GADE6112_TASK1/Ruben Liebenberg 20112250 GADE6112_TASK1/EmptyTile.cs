﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ruben_Liebenberg_20112250_GADE6112_TASK1
{
    public class EmptyTile : Tile///????////
    {
        public EmptyTile(int X, int Y) : base(X,Y)//??//
        { 
          
        }
    }
}
