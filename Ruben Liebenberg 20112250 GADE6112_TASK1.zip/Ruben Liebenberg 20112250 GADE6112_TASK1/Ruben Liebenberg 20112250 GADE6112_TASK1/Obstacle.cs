﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Ruben_Liebenberg_20112250_GADE6112_TASK1
{
    public class Obstacle : Tile
    {
        public Obstacle(int X, int Y) : base(X,Y)
        {
          
        }
    }
}
